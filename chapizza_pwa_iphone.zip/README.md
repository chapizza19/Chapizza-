# CHAPIZZA — app web instalable (PWA)

Esta versión funciona como aplicación web instalable desde Safari en iPhone; no es un archivo IPA.

## Publicar
Sube el contenido completo de la carpeta `www` a un hosting estático que use HTTPS (por ejemplo, un hosting web estático). No abras el HTML directamente como archivo: el manifiesto y el service worker requieren HTTPS o localhost.

## Instalar en iPhone
1. Abre la URL publicada en Safari.
2. Pulsa Compartir.
3. Selecciona **Añadir a pantalla de inicio**.
4. Confirma el nombre `chapizza`.

Incluye los controles visuales de demostración; no interactúan con juegos ni aplicaciones de terceros.

## IPA nativa
Para generar una IPA nativa con Capacitor sigue siendo necesario compilar y firmar el proyecto iOS en Xcode/macOS o mediante un servicio de compilación Mac remoto.
