const toast = document.getElementById('toast');
let toastTimer;
function showToast(message){
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>toast.classList.remove('show'), 2100);
}
// These controls only change the appearance of this demo screen.
// They do not modify or interact with any third-party game or app.
document.querySelectorAll('.toggle').forEach(button=>{
  button.addEventListener('click',()=>{
    const card = button.closest('.option-card');
    const enabled = button.getAttribute('aria-pressed') !== 'true';
    button.setAttribute('aria-pressed', String(enabled));
    card.classList.toggle('active', enabled);
    card.querySelector('.state').textContent = enabled ? 'ON' : 'OFF';
    button.lastChild.textContent = enabled ? ' DEMO ACTIVADA' : ' ACTIVAR DEMO';
    showToast(enabled ? 'Vista de demostración activada' : 'Vista de demostración desactivada');
  });
});
document.getElementById('settingsButton').addEventListener('click',()=>{
  showToast('CHAPIZZA · Versión de demostración');
});
